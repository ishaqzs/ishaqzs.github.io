<!DOCTYPE html>
<html lang="en-US" class="loading-site no-js">
    <head>
        <meta charset="UTF-8"/>
        <link rel="profile" href="http://instagram.com/khanv0"/>
        <link rel="pingback" href="https://khan.af"/>
        <script>
            (function(html) {
                html.className = html.className.replace(/\bno-js\b/, 'js')
            }
            )(document.documentElement);
        </script>
        <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
        <meta name="theme-color" content="#000000">
        <link rel="manifest" href="/manifest.json">
        <link rel="shortcut icon" href="/svd2.svg">
        <link rel="shortcut icon" type="image/svg" href="/svd2"/>
        <link rel="alternate" hreflang="x-default" href="https://khan.af/"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <meta property="og:site_name" content="Isak Khan"/>
        <meta property="article:publisher" content="https://www.khan.af"/>
        <meta property="article:modified_time" content="2024-09-29T06:24:43+00:00"/>
        <meta property="og:image" content="https://khan.af/svd2.svg"/>
        <meta property="og:image:width" content="1200"/>
        <meta property="og:image:height" content="675"/>
        <meta property="og:image:type" content="image/png"/>
        <meta name="twitter:card" content="summary_large_image"/>
        <!-- This site is own by mr isak khan -->
        <title>Isak Khan - Afghan-Norwegian Traveller and Entrepreneur</title>
        <meta name="description" content="Isak Khan, an Afghan-Norwegian adventurer and entrepreneurial spirit who selflessly supports Afghan startups"/>
        <link rel="canonical" href="https://khan.af/"/>
        <meta property="og:locale" content="en_US"/>
        <meta property="og:type" content="website"/>
        <meta property="og:title" content="Isak Khan - Afghan-Norwegian Traveller and Entrepreneur"/>
        <meta property="og:description" content="Isak Khan, an Afghan-Norwegian adventurer and entrepreneurial spirit who selflessly supports Afghan startups"/>
        <meta property="og:url" content="https://khan.af/"/>
        <meta name="hostname" content="khan.af">
        <meta name="expected-hostname" content="khan.af">
        <meta property="og:site_name" content="Isak Khan"/>
        <meta property="article:publisher" content="https://www.khan.af"/>
        <meta property="article:modified_time" content="2024-09-29T06:24:43+00:00"/>
        <meta property="og:image" content="https://khan.af/svd2.svg"/>
        <meta property="og:image:width" content="1200"/>
        <meta property="og:image:height" content="675"/>
        <meta property="og:image:type" content="image/png"/>
        <meta name="twitter:card" content="summary_large_image"/>
        <script type="application/ld+json" class="yoast-schema-graph">
            {
                "@context": "https://schema.org",
                "@graph": [
                    {
                        "@type": "WebPage",
                        "@id": "https://khan.af/",
                        "url": "https://khan.af/",
                        "name": "Isak Khan",
                        "isPartOf": {
                            "@id": "https://khan.af/#website"
                        },
                        "about": {
                            "@id": "https://khan.af/#organization"
                        },
                        "datePublished": "2024-07-17T09:55:54+00:00",
                        "dateModified": "2024-12-16",
                        "description": "Isak Khan, an Afghan-Norwegian adventurer and entrepreneurial spirit who selflessly supports Afghan startups",
                        "breadcrumb": {
                            "@id": "https://khan.af/#breadcrumb"
                        },
                        "inLanguage": "en-US",
                        "potentialAction": [
                            {
                                "@type": "ReadAction",
                                "target": [
                                    "https://khan.af/"
                                ]
                            }
                        ]
                    },
                    {
                        "@type": "BreadcrumbList",
                        "@id": "https://khan.af/#breadcrumb",
                        "itemListElement": [
                            {
                                "@type": "ListItem",
                                "position": 1,
                                "name": "Isak Khan"
                            }
                        ]
                    },
                    {
                        "@type": "WebSite",
                        "@id": "https://khan.af/#website",
                        "url": "https://khan.af/",
                        "name": "Isak Khan",
                        "description": "Afghan-Norwegian Traveller and Entrepreneur",
                        "publisher": {
                            "@id": "https://khan.af/#organization"
                        },
                        "potentialAction": [
                            {
                                "@type": "SearchAction",
                                "target": {
                                    "@type": "EntryPoint",
                                    "urlTemplate": "https://khan.af/?s={search_term_string}"
                                },
                                "query-input": "required name=search_term_string"
                            }
                        ],
                        "inLanguage": "en-US"
                    },
                    {
                        "@type": "Organization",
                        "@id": "https://khan.af/#organization",
                        "name": "Isak Khan",
                        "url": "https://khan.af/",
                        "logo": {
                            "@type": "ImageObject",
                            "inLanguage": "en-US",
                            "@id": "https://khan.af/#/schema/logo/image/",
                            "url": "https://khan.af/svd2.svg",
                            "contentUrl": "https://khan.af/svd2.svg",
                            "width": 696,
                            "height": 696,
                            "caption": "Isak Khan - Afghan-Norwegian Traveller and Entrepreneur"
                        },
                        "image": {
                            "@id": "https://khan.af/#/schema/logo/image/"
                        },
                        "sameAs": [
                            "https://www.instagram.com/khanv0]}]}</script>
                        <!--ppp1-->
                        <script defer="defer" src="/static/js/main.847c76aa.js"></script>
                        <link href="/static/css/main.d68b03d4.chunk.css" rel="stylesheet">
                    </head>
                    <body style="height: 100%; overflow: scroll;">
                        <noscript>You need to enable JavaScript to run this app.</noscript>
                        <div id="root">
                            <div class="home main">
                                <div class="top-menu">
                                    <span class="top-menu-item no-show-mobile">
                                        <a href="mailto:khan@khan.af">Email </a>
                                    </span>
                                    <span class="top-menu-item no-show-mobile">
                                        <a href="https://KiTKdr.com">KiT </a>
                                    </span>
                                    <div class="dropdown">
                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="th" class="svg-inline--fa fa-w-16 fas fa-th dropbtn" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                            <path fill="currentColor" d="M149.333 56v80c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V56c0-13.255 10.745-24 24-24h101.333c13.255 0 24 10.745 24 24zm181.334 240v-80c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24h101.333c13.256 0 24.001-10.745 24.001-24zm32-240v80c0 13.255 10.745 24 24 24H488c13.255 0 24-10.745 24-24V56c0-13.255-10.745-24-24-24H386.667c-13.255 0-24 10.745-24 24zm-32 80V56c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24h101.333c13.256 0 24.001-10.745 24.001-24zm-205.334 56H24c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24h101.333c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24zM0 376v80c0 13.255 10.745 24 24 24h101.333c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H24c-13.255 0-24 10.745-24 24zm386.667-56H488c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H386.667c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24zm0 160H488c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H386.667c-13.255 0-24 10.745-24 24v80c0 13.255 10.745 24 24 24zM181.333 376v80c0 13.255 10.745 24 24 24h101.333c13.255 0 24-10.745 24-24v-80c0-13.255-10.745-24-24-24H205.333c-13.255 0-24 10.745-24 24z"></path>
                                        </svg>
                                        <div id="drop" class="dropdown-content-cont dropdown-hide">
                                            <div class="drop-item">
                                                <a class="drop-link" href="/">
                                                    <img src="https://khan.af/svd2.svg" alt="">
                                                    <p>Search </p>
                                                </a>
                                                <a class="drop-link" href="/about">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e4/Infobox_info_icon.svg" alt="">
                                                    <p>About </p>
                                                </a>
                                                <a class="drop-link" href="/works">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/50/Business_Suitcase_Flat_Icon.svg" alt="">
                                                    <p>Works </p>
                                                </a>
                                                <a class="drop-link" href="/blog">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/c/ca/Icon_Notes.svg" alt="">
                                                    <p>Blog </p>
                                                </a>
                                                <a class="drop-link" href="/images">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/d1/Khost_children_in_2009.jpg" alt="">
                                                    <p>Images </p>
                                                </a>
                                                <a class="drop-link" href="mailto:khan@khan.af">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/7/7e/Gmail_icon_(2020).svg" alt="">
                                                    <p>Email </p>
                                                </a>
                                                <a class="drop-link" href="https://linkedin.com/in/IsakKhan">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/8/81/LinkedIn_icon.svg" alt="">
                                                    <p>LinkedIn </p>
                                                </a>
                                                <a class="drop-link" href="https://www.Instagram.com/Khanv0">
                                                    <img src="https://upload.wikimedia.org/wikipedia/commons/e/e7/Instagram_logo_2016.svg" alt="">
                                                    <p>Instagram</p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="profile dropdown">
                                        <img class="profile-pic dropbtn" https://khan.af/svd2.svg alt="profile">
                                        <div class="profile-hightlight-dropdown">
                                            <p>Portfolio Website </p>
                                            <p>Isak Khan</p>
                                            <p>khan@khan.af </p>
                                        </div>
                                        <div class="profile-details-dropdown dropdown-hide">
                                            <div class="first-detail">
                                                <img class="://khan.af/svd2.svg" alt="profile">
                                                <p class="detail-text">Isak Khan </p>
                                                <p class="detail-text">khan@khan.af </p>
                                                <a href="https://khan.af">Homepage</a>
                                            </div>
                                            <a class="second-detail" href="/about">
                                                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user-plus" class="svg-inline--fa fa-w-20 fa-user-plus" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                                                    <path fill="currentColor" d="M624 208h-64v-64c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v64h-64c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h64v64c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16v-64h64c8.8 0 16-7.2 16-16v-32c0-8.8-7.2-16-16-16zm-400 48c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"></path>
                                                </svg>
                                                <p>More about me </p>
                                            </a>
                                            <div class="third-detail">
                                                <a href="https://kitkdr.com/JoseRoque">KiT</a>
                                            </div>
                                            <div class="fourth-detail">
                                                <a href="https://HOPPinn.no">HOPPinn </a>
                                                <span>• </span>
                                                <a href="/blog">Blog &amp;news </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex-center">
                                    <div class="search-container">
                                        <div class="frontpage-logo">
                                            <div class="search-logo">
                                                <div class="logo-text">
                                                    <h1 class="blue">K</h1>
                                                    <h1 class="red">H</h1>
                                                    <h1 class="yellow">A</h1>
                                                    <h1 class="blue">N</h1>
                                                    <h1 class="green"></h1>
                                                    <h1 class="red">.</h1>
                                                    <h1 class="yellow">a</h1>
                                                    <h1 class="red">f</h1>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div>
                                                <div class="mobile-search-box">
                                                    <div class="mobile-search-cont">
                                                        <div class="mobile-search">
                                                            <div class="mobile-search-value">
                                                                <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-left" class="svg-inline--fa fa-arrow-left fa-w-14 searchbar-icon back-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                                                    <path fill="currentColor" d="M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z"></path>
                                                                </svg>
                                                                <input placeholder=" " autocomplete="on" class="mobile-search-input" value="">
                                                                <svg aria-labelledby="svg-inline--fa-title-1PY5c4e5ftQy" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 searchbar-icon mobile-clear-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512" style="display: none;">
                                                                    <title id="svg-inline--fa-title-1PY5c4e5ftQy">Clear</title>
                                                                    <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                </svg>
                                                            </div>
                                                            <div class="mobile-search-select">
                                                                <div class="mobile-search-options">
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/all">everything about you</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-LQi5kWscd1l8" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-LQi5kWscd1l8">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/about">about</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-fGV8elOMzXI3" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-fGV8elOMzXI3">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/works">works</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-TDutoCKwNDOh" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-TDutoCKwNDOh">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/writing">writing</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-zt4zx3boVufT" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-zt4zx3boVufT">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/images">images</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-budIVC6lYSZm" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-budIVC6lYSZm">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                    <div class="mobile-search-option" type="button">
                                                                        <span>
                                                                            <span>
                                                                                <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="clock" class="svg-inline--fa fa-clock fa-w-16 clock-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                                                    <path fill="currentColor" d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm61.8-104.4l-84.9-61.7c-3.1-2.3-4.9-5.9-4.9-9.7V116c0-6.6 5.4-12 12-12h32c6.6 0 12 5.4 12 12v141.7l66.8 48.6c5.4 3.9 6.5 11.4 2.6 16.8L334.6 349c-3.9 5.3-11.4 6.5-16.8 2.6z"></path>
                                                                                </svg>
                                                                                <a href="/social">social</a>
                                                                            </span>
                                                                            <svg aria-labelledby="svg-inline--fa-title-PAAvt4XK301x" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11 delete-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512">
                                                                                <title id="svg-inline--fa-title-PAAvt4XK301x">Clear</title>
                                                                                <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                                            </svg>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="search-box">
                                                <div class="search-cont">
                                                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="search" class="svg-inline--fa fa-w-16 fa fa-search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                                        <path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                                                    </svg>
                                                    <div class="search">
                                                        <div class="search-value">
                                                            <input placeholder=" " autocomplete="on" class="search-input" value="">
                                                        </div>
                                                        <div class="search-select">
                                                            <div class="search-options">
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/all">about me</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/about">about</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/works">works</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/blog">blog</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/images">images</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                                <div class="search-option" type="button">
                                                                    <span>
                                                                        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="history" class="svg-inline--fa fa-history fa-w-16 fas" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(170, 170, 170);">
                                                                            <path fill="currentColor" d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"></path>
                                                                        </svg>
                                                                        <a href="/social">social</a>
                                                                        <span>
                                                                            <button class="remove-btn" style="vertical-align: middle; margin-right: 10px; font-size: 13px; color: rgb(85, 85, 85); border: 0px; outline: none; background: transparent; float: right; padding: 10px; cursor: pointer;">Remove</button>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div class="search-btns" style="padding-top: 20px; padding-bottom: 30px;">
                                                                <input class="search-btn sw" type="button" value="Search Website">
                                                                <input class="search-btn ifl" type="button" value="I'm Feeling Lucky">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <svg aria-labelledby="svg-inline--fa-title-kx1AoNsjfGiY" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-w-11 fa fa-times clear-icon" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512" style="display: none;">
                                                        <title id="svg-inline--fa-title-kx1AoNsjfGiY">Clear</title>
                                                        <path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="search-btns">
                                            <input class="search-btn sw" type="button" value="Search Website">
                                            <input class="search-btn ifl" type="button" value="I'm Feeling Lucky">
                                        </div>
                                    </div>
                                </div>
                                <footer class="footer">
                                    <div class="footer-links">
                                        <div class="footer-links-section">
                                            <a href="/about">About </a>
                                            <a href="/projects">Projects </a>
                                            <a href="/blog">Blog</a>
                                            <a href="mailto:khan@khan.af">Email </a>
                                        </div>
                                        <div class="footer-links-section">
                                            <a href="https://khan.af">KHAN.af</a>
                                            <a href="https://www.instagram.com/khanv0">LinkedIn </a>
                                            <a href="mailto:khan@khan.af">Email </a>
                                        </div>
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </body>
                </html>
